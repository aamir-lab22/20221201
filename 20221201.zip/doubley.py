import matplotlib.pyplot as plt

years = range(2000, 2010)
divorce_rate = [5.0, 4.7, 4.6, 4.4, 4.3, 4.1, 4.2, 4.2, 4.2, 4.1]
margerine_consumption = [8.2, 7, 6.5, 5.3, 5.2, 4, 4.6, 4.5, 4.2, 3.7]

line1 = plt.plot(years, divorce_rate, 'b-o', label="Divorce Rate")
plt.grid()
plt.ylabel("Divorce per 1000 people")

plt.twinx()
line2 = plt.plot(years, margerine_consumption, 'r-o', label="Margerine consumption")
plt.ylabel("Margerine consumption")

lines = line1 + line2
labels = []
for line in lines:
	labels.append(line.get_label())


plt.xlabel("Years")
plt.title("Twin axis plot")
plt.legend(lines, labels)
plt.show()
