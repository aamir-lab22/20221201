import matplotlib.pyplot as plt
import random as random

data = []
for i in range(5000):
	data.append(random.normalvariate(0, 2))

plt.hist(data, bins=20, density=True, edgecolor='black')
plt.xlabel("Distribution")
plt.ylabel("Frequency")
plt.title("Histogram")
plt.grid()
plt.show()
