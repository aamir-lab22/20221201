import numpy as np
import random as random
import time
"""
x = [random.randint(25, 88) for i in range(1000000)]
y = [random.randint(1, 1000) for i in range(1000000)]
time_in = time.time()
z = [x[i]*y[i] for i in range(len(x))]
time_out = time.time()
print(time_out - time_in)
	

x = np.zeros(1000000)
for i in range(1000000):
	x[i] = np.random.randint(25, 88)

y = np.zeros(1000000)
for i in range(1000000):
	y[i] = np.random.randint(1, 1000)

time_in = time.time()
z = x*y
time_out = time.time()
print(time_out - time_in)

# Creating arrays

a = np.array([1, 2, 3])
print(a)

# Create 2d array
a = np.array([[1, 2], [3, 4]])
print(a)

# a 2d array
a = np.array([1, 2, 3, 4, 5], ndmin=2)
print(a)

# a 3d array
a = np.array([1, 2, 3, 4, 5], ndmin=3)
print(a)

# reshaping
a = np.array([[1, 2, 3], [4, 5, 6]])
print(a.shape)
a.shape = (3, 2)
print(a)
print(a.shape)

# reshaping
a = np.array([[1, 2, 3], [4, 5, 6]])
a = a.reshape(3, 2)
print(a)

# evenly spaced numbers
a = np.arange(24)
print(a)
a = np.arange(3, 30)
print(a)
a = np.arange(3, 30, 2)
print(a)

# reshaping
a = np.arange(24)
print(a)
a = a.reshape(3, 8)
print(a)
a = a.reshape(2, 4, 3)
print(a)

x = np.empty([3, 2])
print(x)
for i in range(3):
	for j in range(2):
		x[i,j] = random.randint(1,9)
print(x)

x = np.zeros(25)
print(x)
print("How to generate a 5 x 5 zero null matrix?")

x = np.ones(25)
print(x)

x = np.eye(5)
print(x)

# convert list to array
x = [1, 2, 3]
a = np.asarray(x)
print(a)

a = np.array([1, 2, 3])
print(a)
a = np.array([1, 2, 3], dtype=float)
print(a)

a = np.linspace(0, 1, 1000)
print(a)
a = np.linspace(0, 1, 1000, endpoint=False)
print(a)

a = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(a)
b = a[1:]
print(b)
print("a slices")
print(a[1])
print(a[:,1:])
"""
